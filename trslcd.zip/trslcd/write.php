<?php include 'connect.php';?>

<?php
	
    //Insert data into the table (products)
    //Insert data into each column (product_id...etc)
    $statement = $DB->prepare("INSERT INTO iphone_lcd (product_id, product_name, product_price, product_info)
    VALUES (NULL,'iphone 11 lcd', 25,'original glass change lcd')
    ");
    $statement->execute();

    Echo 'Database successfully updated!';


?>