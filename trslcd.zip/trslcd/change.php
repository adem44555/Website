<html>
    <head>
    </head>
    <body>

    <form method="post">

        <label for="pid">Product ID:</label>
            <input type="text" name="pid"><br><br>


        <label for="pprice">Product Price:</label>
            <input type="text" name="pprice"><br><br>
            

            <input type="submit" name="button1"
                    value="Insert"/>
         
    </form>

    </body>
</html>

<?php

   //if statement to check if the update button has been clicked
    //if true, store the input data as variables 
    if(isset($_POST['button1'])) {

        $pid = $_POST["pid"];
        $pprice = $_POST["pprice"];
        
        $statement=$DB->prepare("UPDATE products SET product_price = '$pprice' WHERE product_id = '$pid';");
        $statement->execute();

    $statement->execute();
} 

?>