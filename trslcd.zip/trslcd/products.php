<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name = "author" content = "Adem Oncu">
    <meta name = "content" content = "Whosaleing Company">
    <title>TRS LCD</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <nav>
        <img id="logo" src="images/trs logo.jpg" alt = "logo pic">
        <ul>
            <li><a href="index1.html">Home</a></li>
            <li><a href="iphone.html">IPhone LCD</a></li>
            <li><a href="samsung.html">Samsung LCD</a></li>
            <li><a href="iphonebat.html">IPhone Battery</a></li>
            <li><a href="samsungbat.html">Samsung Battery</a></li>
            <li><a href="contactus.html">Contact Us</a></li>
            <li><a href="Login.html">Login</a></li>

        </ul>
    </nav>


<?php include 'connect.php';?>

<?php

//Prepares an SQL statement to be executed by the execute() method

    $statement = $DB->prepare("SELECT * FROM iphone_lcd"); //change to your 'table' name
        
//Executes a prepared statement
		
    $statement->execute();
        
//Returns an array containing all of the remaining rows in the result set
		
    $result = $statement->fetchAll();

		if($result){
			echo '<table cellpadding="5" border="1" width="400">
					<tr>
						<th>ID</th>
						<th>Product</th>
						<th>Price</th>
                        <th>Info</th>
						<th>Image</th>
                                                
					</tr>';
			foreach ($result as $rs) {
				echo '<tr>
						<td>'.$rs['product_id'].'</td> 
						<td>'.$rs['product_name'].'</td>
						<td>'.$rs['product_price'].'</td>
                        <td>'.$rs['product_info'].'</td>
						<td><img src="'.$rs['product_img'].'"></td>
					  </tr>';
			}
            echo '</table>';
		}else{
			echo "No result Found";
		}

?>