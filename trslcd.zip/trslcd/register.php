<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name = "author" content = "Adem Oncu">
    <meta name = "content" content = "Whosaleing Company">
    <title>TRS LCD</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <nav>
        <img id="logo" src="images/trs logo.jpg" alt = "logo pic">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="iphone.html">IPhone LCD</a></li>
            <li><a href="samsung.html">Samsung LCD</a></li>
            <li><a href="iphonebat.html">IPhone Battery</a></li>
            <li><a href="samsungbat.html">Samsung Battery</a></li>
            <li><a href="contactus.html">Contact Us</a></li>
            <li><a href="login.php">Staff Login</a></li>
            <li><a href="userlogin.php">User Login</a></li>

        </ul>
    </nav>




<?php include 'connect.php';?>



<h2>Register a new user</h2>
        <p>Please enter your details below to register your information</p>
        
        <form method="post">
            <div class="form-group">
                <label for="emailbox">Email address</label>
                <input type="email" id="emailbox" name="newemail" placeholder="Enter email">
            </div>
            <div class="form-group">
                <label for="passwordbox">Password</label>
                <input type="password" id="passwordbox" name="newpass" placeholder="Password">
            </div>

            <button type="submit" name="newlogin">Submit</button>
        </form>

        <?php

            //if statement to check if the form button has been clicked
        
            if(isset($_POST['newlogin'])) {

                //Check if the email is already taken (Exists in the database)

                $statement = $DB->prepare("SELECT * FROM users WHERE user_email = '".$_POST['newemail']."'");
                
                $statement->execute();

                $count = $statement->rowCount();

                if($count > 0){
				echo "Email already taken, please try again...";
                } else {

                $username = trim($_POST['newemail']);
                $password = trim($_POST['newpass']);

                //Pass the variable values to be inserted into the database
                    
                $statement = $DB->prepare("INSERT INTO users (user_id, user_email, user_password)
                VALUES (NULL, '$username', '$password')");

                $statement->execute();

                echo "Success, you have registered your details!";

                } 
            }

        ?>

