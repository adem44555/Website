<?php
session_start(); //  Start session at the very beginning
include 'connect.php';

if (isset($_POST['myLogin'])) { 

    // Store and sanitize input
    $username = trim($_POST['staffemail']);
    $password = trim($_POST['staffpass']);

    // Prepare a safe SQL query using placeholders (avoids SQL injection)
    $statement = $DB->prepare("SELECT * FROM staff WHERE staff_email = :email AND staff_pass = :password");
    
    // Bind parameters securely
    $statement->bindParam(':email', $username, PDO::PARAM_STR);
    $statement->bindParam(':password', $password, PDO::PARAM_STR);
    
    // Execute query
    $statement->execute();

    // Check if a user exists
    if ($statement->rowCount() == 1) {
        $row = $statement->fetch();

        //  Store session variable for login
        $_SESSION["userdb"] = true;
        $_SESSION["staff_name"] = $row['staff_fname'];
        $_SESSION["staff_job"] = $row['staff_job'];

        // Display success message
        echo "<h1>You have logged in.</h1>";
        echo "<h2>Employee ID: " . htmlspecialchars($row['staff_id']) . "</h2>";
        echo "<p>TRS_LCD welcomes you, " . htmlspecialchars($row['staff_fname']) . "</p>";
       
        

        


    } else {
        echo "<h1>Error logging in, please try again...</h1>";
    }

} else {
    echo "<h1>You don't have permission to see this page. Please <a href='login.php'>login</a></h1>";
}


?>
