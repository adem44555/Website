<html>
    <head>
    </head>
    <body>

    <form method="post">

        <label for="pname">Product Name:</label>
            <input type="text" name="pname"><br><br>

        <label for="pprice">Product Price:</label>
            <input type="text" name="pprice"><br><br>
            
        <label for="pinfo">Product Info:</label>
            <input type="text" name="pinfo"><br><br>

            <input type="submit" name="button1"
                    value="Insert"/>
            
            <input type="submit" name="button2"
                    value="View"/>
    </form>

    </body>
</html>

<?php

    //if statement to check if the insert button has been clicked
    //if true, store the input data as variables
 
    if(isset($_POST['button1'])) {

        $pname = $_POST["pname"];
        $pprice = $_POST["pprice"];
        $pinfo = $_POST["pinfo"];

    //Pass the variable values to be inserted into the database
         
    $statement = $GLOBALS['DB']->prepare("INSERT INTO products (product_id, product_name, product_price, product_info)
    VALUES (NULL, '$pname', '$pprice', '$pinfo')
    ");

    $statement->execute();
} 

?>