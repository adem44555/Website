<?php
include 'connect.php';
session_start();

// Handle Staff Login
if (isset($_POST['myLogin'])) {
    $staff_email = trim($_POST['staffemail']);
    $staff_password = trim($_POST['staffpass']);

    $statement = $DB->prepare("SELECT * FROM staff WHERE staff_email = ?");
    $statement->execute([$staff_email]);
    $staff = $statement->fetch(PDO::FETCH_ASSOC);

    if ($staff && password_verify($staff_password, $staff['staff_password'])) {
        $_SESSION['staff_logged_in'] = true;
        $_SESSION['staff_email'] = $staff_email;
        header("Location: staff_dashboard.php"); // Redirect to staff dashboard
        exit();
    } else {
        $login_error = "Invalid login details. Please try again.";
    }
}

// Handle Staff Registration
if (isset($_POST['register_staff'])) {
    $staff_email = trim($_POST['staff_reg_email']);
    $staff_password = password_hash(trim($_POST['staff_reg_pass']), PASSWORD_DEFAULT);

    // Check if email already exists
    $statement = $DB->prepare("SELECT * FROM staff WHERE staff_email = ?");
    $statement->execute([$staff_email]);

    if ($statement->rowCount() > 0) {
        $register_error = "Email already taken, please try again.";
    } else {
        $statement = $DB->prepare("INSERT INTO staff (staff_email, staff_password) VALUES (?, ?)");
        if ($statement->execute([$staff_email, $staff_password])) {
            $register_success = "Success! Staff member registered.";
        } else {
            $register_error = "Error: Could not register staff.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="Adem Oncu">
    <meta name="content" content="Wholesale Company">
    <title>TRS LCD - Staff Login & Register</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <nav>
        <img id="logo" src="images/trs logo.jpg" alt="logo pic">
        <ul>
            <li><a href="index1.html">Home</a></li>
            <li><a href="iphone.html">IPhone LCD</a></li>
            <li><a href="samsung.html">Samsung LCD</a></li>
            <li><a href="iphonebat.html">IPhone Battery</a></li>
            <li><a href="samsungbat.html">Samsung Battery</a></li>
            <li><a href="contactus.html">Contact Us</a></li>
            <li><a href="userlogin.php">User Login</a></li>
        </ul>
    </nav>

    <h2>Staff Login</h2>
    <?php if (isset($login_error)) echo "<p style='color:red;'>$login_error</p>"; ?>
    <form method="post">
        <div class="form-group">
            <label for="emailbox">Email address</label>
            <input type="email" id="emailbox" name="staffemail" placeholder="Enter email" required>
        </div>
        <div class="form-group">
            <label for="passwordbox">Password</label>
            <input type="password" id="passwordbox" name="staffpass" placeholder="Password" required>
        </div>
        <button type="submit" name="myLogin">Login</button>
    </form>

    <hr>

    <h2>Register a New Staff Member</h2>
    <?php 
        if (isset($register_error)) echo "<p style='color:red;'>$register_error</p>";
        if (isset($register_success)) echo "<p style='color:green;'>$register_success</p>";
    ?>
    <form method="post">
        <div class="form-group">
            <label for="staff-email">Email address</label>
            <input type="email" id="staff-email" name="staff_reg_email" placeholder="Enter email" required>
        </div>
        <div class="form-group">
            <label for="staff-password">Password</label>
            <input type="password" id="staff-password" name="staff_reg_pass" placeholder="Password" required>
        </div>
        <button type="submit" name="register_staff">Register</button>
    </form>

</body>
</html>
