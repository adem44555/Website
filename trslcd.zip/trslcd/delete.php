<html>
    <head>
    </head>
    <body>

    <form method="post">

        <label for="pid">Product ID:</label>
            <input type="text" name="pid"><br><br>

<input type="submit" name="button1"
                    value="Insert"/>
            
          
    </form>

    </body>
</html>


<?php 


    //if statement to check if the update button has been clicked
    //if true, delete the record with the id 
    if(isset($_POST['button1'])) {

        $pid = $_POST["pid"];
                
        $statement=$DB->prepare("DELETE FROM products WHERE product_id = '$pid'");
        $statement->execute();

    $statement->execute();
} 

?>