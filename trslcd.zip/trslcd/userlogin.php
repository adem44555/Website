<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name = "author" content = "Adem Oncu">
    <meta name = "content" content = "Whosaleing Company">
    <title>TRS LCD</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <nav>
        <img id="logo" src="images/trs logo.jpg" alt = "logo pic">
        <ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="iphone.html">IPhone LCD</a></li>
            <li><a href="samsung.html">Samsung LCD</a></li>
            <li><a href="iphonebat.html">IPhone Battery</a></li>
            <li><a href="samsungbat.html">Samsung Battery</a></li>
            <li><a href="contactus.html">Contact Us</a></li>
            <li><a href="login.php">Staff Login</a></li>
            <li><a href="userlogin.php">User Login</a></li>

        </ul>
    </nav>






    <?php include 'connect.php'; ?>

<h2>User Login</h2>
<form method="post">
    <div class="form-group">
        <label for="login-email">Email address</label>
        <input type="email" id="login-email" name="loginemail" placeholder="Enter email">
    </div>
    <div class="form-group">
        <label for="login-password">Password</label>
        <input type="password" id="login-password" name="loginpass" placeholder="Password">
    </div>
    <button type="submit" name="userlogin">Login</button>
</form>

<?php
if (isset($_POST['userlogin'])) {
    // Handle user login
    $statement = $DB->prepare("SELECT * FROM users WHERE user_email = ? LIMIT 1");
    $statement->execute([$_POST['loginemail']]);
    $user = $statement->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($_POST['loginpass'], $user['user_password'])) {
        echo "Login successful!";
        // Redirect or start session
    } else {
        echo "Invalid login details!";
    }
}
?>

<hr>

<h2>Register a new user</h2>
<p>Please enter your details below to register.</p>

<form method="post">
    <div class="form-group">
        <label for="emailbox">Email address</label>
        <input type="email" id="emailbox" name="newemail" placeholder="Enter email">
    </div>
    <div class="form-group">
        <label for="passwordbox">Password</label>
        <input type="password" id="passwordbox" name="newpass" placeholder="Password">
    </div>
    <button type="submit" name="newlogin">Register</button>
</form>

<?php
if (isset($_POST['newlogin'])) {
    $statement = $DB->prepare("SELECT * FROM users WHERE user_email = ?");
    $statement->execute([$_POST['newemail']]);
    
    if ($statement->rowCount() > 0) {
        echo "Email already taken, please try again...";
    } else {
        $username = trim($_POST['newemail']);
        $password = password_hash(trim($_POST['newpass']), PASSWORD_DEFAULT); // Secure hashing

        $statement = $DB->prepare("INSERT INTO users (user_email, user_password) VALUES (?, ?)");
        $statement->execute([$username, $password]);

        echo "Success, you have registered!";
    }
}
?>
